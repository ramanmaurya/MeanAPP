import { UserService } from './user.service';
export declare class UserController {
    private readonly userService;
    constructor(userService: UserService);
    adduser(completeBody: {
        userName: String;
        userPhone: Number;
        userEmail: String;
        userProfile: String;
    }): any;
    alluser(): Promise<any[]>;
    getsingle(prodid: string): Promise<any>;
    updateUser(prodid: string, completeBody: {
        userName: String;
        userPhone: Number;
        userEmail: String;
        userProfile: String;
    }): any;
    DeleteUser(prodid: string): any;
}
