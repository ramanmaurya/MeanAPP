import { Model } from 'mongoose';
import { UserModelData } from './user.model';
export declare class UserService {
    private readonly userModel;
    constructor(userModel: Model<any, UserModelData>);
    createUser(user: object): Promise<any>;
    fetchsingleUser(id: any): Promise<any>;
    fetchAllUser(): Promise<any[]>;
    fetchUpdate(id: any, updatedate: any): Promise<{
        ok: number;
        n: number;
        nModified: number;
    }>;
    deleteingleUser(id: any): Promise<{
        ok?: number;
        n?: number;
    } & {
        deletedCount?: number;
    }>;
}
