import * as mongoose from "mongoose";
export declare const userSchema: mongoose.Schema<mongoose.Document<any, {}>, mongoose.Model<any, any>, undefined>;
export interface UserModelData {
    userName: string;
    userPhone: string;
    userEmail: string;
    userProfile: string;
}
