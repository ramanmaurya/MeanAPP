"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authuserloginCredentialSchema = void 0;
const mongoose = require("mongoose");
exports.authuserloginCredentialSchema = new mongoose.Schema({
    user_name: { type: String, required: true },
    user_email: { type: String, required: true },
    user_passowrd: { type: String, required: true },
});
//# sourceMappingURL=auth.model.js.map