import { Model } from 'mongoose';
import { AuthuserloginCredential } from './auth.model';
export declare class AuthService {
    private readonly UserLoginService;
    constructor(UserLoginService: Model<any, AuthuserloginCredential>);
    validateUser(username: any): Promise<any>;
    createUser(user: object): Promise<any>;
}
