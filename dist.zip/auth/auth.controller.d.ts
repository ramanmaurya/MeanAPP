import { AuthService } from './auth.service';
export declare class AuthController {
    private readonly userService;
    constructor(userService: AuthService);
    adduser(completeBody: {
        user_name: String;
        user_email: String;
        user_passowrd: String;
    }): any;
    authuser(completeBody: {
        user_name: String;
        user_email: String;
        user_passowrd: String;
    }): any;
}
