export declare class UserLoginModule {
}
