import { Model } from 'mongoose';
import { userloginCredential } from './user-login.model';
export declare class UserLoginService {
    private readonly userloginModel;
    constructor(userloginModel: Model<any, userloginCredential>);
    findOne(username: string): Promise<any>;
}
