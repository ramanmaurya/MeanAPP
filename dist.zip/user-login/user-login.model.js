"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.userloginCredentialSchema = void 0;
const mongoose = require("mongoose");
exports.userloginCredentialSchema = new mongoose.Schema({
    user_name: { type: String, required: true },
    user_email: { type: String, required: true },
    user_passowrd: { type: String, required: true },
});
//# sourceMappingURL=user-login.model.js.map