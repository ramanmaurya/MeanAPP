import * as mongoose from "mongoose";
export declare const userloginCredentialSchema: mongoose.Schema<mongoose.Document<any, {}>, mongoose.Model<any, any>, undefined>;
export interface userloginCredential {
    user_name: string;
    user_email: string;
    user_passowrd: string;
}
