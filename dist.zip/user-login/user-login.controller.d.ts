export declare class UserloginController {
    constructor();
}
